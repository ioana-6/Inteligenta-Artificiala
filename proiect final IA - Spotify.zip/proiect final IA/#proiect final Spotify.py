#proiect final Spotify

import pyautogui
import keyboard
import time
import cv2

def delogare():
    buton_profil=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\iconitaprofil.png', confidence=0.7)
    pyautogui.click(buton_profil)
    time.sleep(2)
    buton_delogare=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\deconectare.png', confidence=0.7)
    pyautogui.click(buton_delogare)

def logare():
    if pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\New folder\browser.png', confidence=0.7) != None:
        camp_google=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\New folder\browser.png', confidence=0.7)
        pyautogui.click(camp_google)
        time.sleep(2)
        pyautogui.write('open.spotify.com/')
        pyautogui.press('enter')
        time.sleep(7)
        if pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\bunaseara.png', confidence=0.7) != None:
            print ("Sunteti logat(ă). ")
            ##tasta = input("Doriți să vă delogați? Apăsați tasta 'D' pentru 'Da', tasta 'N' pentru 'Nu'.")
            ##print(tasta)
            ##if tasta == 'n':
                ##print("Okay.")
            ##elif tasta == 'd':
                ##delogare()
        else:
            buton_logare=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\butonlogare.png', confidence=0.7)
            pyautogui.click(buton_logare)
            time.sleep(4)
            logare_Facebook=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\logareFacebook.png', confidence=0.7)
            pyautogui.click(logare_Facebook)
            time.sleep(8)

logare()

def preatare():
    if pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\preatare.png', confidence=0.7) != None:
        x, y = pyautogui.locateCenterOnScreen(r'C:\Users\PC\Desktop\proiect final IA\preatare.png', confidence=0.7)
        pyautogui.moveTo(x,y)
        time.sleep(2)
        x,y = pyautogui.position()
        pyautogui.dragTo(x+60,y)
        pyautogui.mouseUp

def schimba_dispozitiv():
    buton_dispozitive=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\altdispozitiv.png', confidence=0.7)
    pyautogui.click(buton_dispozitive)
    time.sleep(2)
    buton_browser=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\acestbrowser.png', confidence=0.7)
    pyautogui.click(buton_browser)
    time.sleep(2)
    preatare()

def da_pe_mut():
    mute=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\mute.png', confidence=0.7)
    pyautogui.click(mute)

def skip():
    skip=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\skip.png', confidence=0.7)
    pyautogui.click(skip)

def piua():
    piua=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\piua.png', confidence=0.7)
    pyautogui.click(piua)

def shuffle():
    shuffle=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\shuffleoff.png', confidence=0.7)
    pyautogui.click(shuffle)

def inapoi():
    inapoi=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\inapoi.png', confidence=0.7)
    pyautogui.click(inapoi)

def ocr():
    fila_noua=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\filanoua.png', confidence=0.7)
    pyautogui.click(fila_noua)
    time.sleep(3)
    camp_google=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\New folder\browser.png', confidence=0.7)
    pyautogui.click(camp_google)
    pyautogui.write('www.onlineocr.net/')
    pyautogui.press('enter')
    time.sleep(3)
    buton_fisier=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\fisier.png', confidence=0.7)
    pyautogui.click(buton_fisier)
    time.sleep(2)
    pyautogui.write(r'\Users\PC\Desktop\proiect final IA\output\screenshot.png')
    time.sleep(1)
    pyautogui.press('enter')
    time.sleep(3) 
    converteste=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\converteste.png', confidence=0.7)
    pyautogui.click(converteste)

def cele10piese():
    buton_profil=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\iconitaprofil.png', confidence=0.7)
    pyautogui.click(buton_profil)
    time.sleep(1)
    intra_profil=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\profil.png', confidence=0.7)
    pyautogui.click(intra_profil)
    time.sleep(3)
    pyautogui.scroll(-500)
    mai_multe=pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\more.png', confidence=0.7)
    pyautogui.click(mai_multe)
    pyautogui.scroll(-100)
    x,y = pyautogui.position()
    pyautogui.moveTo(x+100,y)
    myscreenshot = pyautogui.screenshot(region=(249,185,1125,772))
    myscreenshot.save(r'C:\Users\PC\Desktop\proiect final IA\output\screenshot.png')
    

if pyautogui.locateOnScreen(r'C:\Users\PC\Desktop\proiect final IA\bandaaltdispozitiv.png', confidence=0.7) != None:
    schimba_dispozitiv()

cele10piese()


print("'S': săriți piesa curentă \n 'M': puneți muzica pe mut \n 'P': puneți pauză \n 'A': redați piesele în ordine aleatorie \n 'I': redați piesa anterioară \n 'X': închideți \n")

while 1:
    next = input("Ce doriți să faceți în continuare?")
    if next == 's':
        skip()
    elif next == 'm':
        da_pe_mut()
    elif next == 'p':
        piua()
    elif next == 'a':
        shuffle()
    elif next == 'i':
        inapoi()
    elif next == 'x':
        delogare()
        break